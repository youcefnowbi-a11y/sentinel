# Sentinel Skill Spec

Date: 2026-04-26

## Source Lessons

- Hermes builds skill prompt indexes from local/external dirs (`agent-lab/vendors/hermes-agent/source/agent/prompt_builder.py:621-708`).
- Hermes skill commands may point the agent toward scripts (`agent-lab/vendors/hermes-agent/source/agent/skill_commands.py:137-202`).
- OpenJarvis imports skills from external sources and can import scripts (`agent-lab/vendors/openjarvis/source/src/openjarvis/cli/skill_cmd.py:162-245`; `skills/importer.py:128-135`).
- OpenJarvis has dangerous capability vocabulary (`agent-lab/vendors/openjarvis/source/src/openjarvis/skills/security.py:11-55`).

## Skill Manifest

```json
{
  "id": "skill_...",
  "name": "...",
  "version": "...",
  "source": {
    "type": "local|github|vendor|generated",
    "url": null,
    "commit": null,
    "path": "..."
  },
  "description": "...",
  "instructions_path": "SKILL.md",
  "required_tools": [],
  "required_secrets": [],
  "filesystem": {
    "read_roots": [],
    "write_roots": []
  },
  "network": {
    "domains": [],
    "methods": []
  },
  "external_effects": [],
  "risk_level": "low|medium|high|critical",
  "approval_required": true,
  "tests": [],
  "scanner_report_id": "scan_..."
}
```

## Classification

- `safe_static_doc`: docs and templates only, no tool/action instruction.
- `draft_only_tool`: creates content but cannot send/publish.
- `needs_review`: reads data, queries web/API, or imports untrusted context.
- `blocked`: shell, install, browser submit, external send, secrets, filesystem outside allowed roots, code mutation.

## Promotion Flow

```text
source candidate
-> static scan
-> manifest normalization
-> risk classification
-> sandbox fake eval
-> user review
-> SkillIndexCompiler
```

## Runtime Rule

Skill text cannot execute anything. It can only propose structured actions. The executor only acts after Firewall.

## Required Evals

- Malicious prompt-only skill blocked.
- Script-bearing skill quarantined.
- Missing manifest field blocks promotion.
- External-send skill becomes draft-only or blocked.
- Skill cannot change policy.
