# Sentinel Runtime Capability Roadmap

Date: 2026-04-26

## Capability Gates

No capability graduates without:

- source lesson;
- original Sentinel spec;
- risk class;
- policy rule;
- dry-run format;
- approval rule;
- trace schema;
- fake benchmark;
- regression eval.

## Roadmap

| Phase | Capability | Vendor lesson | Sentinel action |
| --- | --- | --- | --- |
| Now | Evidence-backed GTM Pack | CueIdea/S1/S2 | Improve pack specificity and evidence density |
| Now | AgentOps Firewall | JARVIS authority and approval, OpenClaw scanner | Keep v1 execution narrow and controlled |
| Now | Skill Scanner | OpenClaw B2/B2.5, OpenJarvis skill import | Expand scanner from OpenClaw to generic SkillSpec |
| Next | CostRouter | OpenJarvis hardware/model routing | Add budget-aware route logs before any costly deep run |
| Next | Memory v0 | Hermes memory, JARVIS vault | Add typed memory with no policy authority |
| Later | Read-only browser | JARVIS templates, OpenClaw browser risk | Isolated profile, no submit, source extraction only |
| Later | Channel adapters | OpenClaw/Hermes/OpenJarvis channels | Inbound untrusted; outbound draft-only |
| Later | Permissioned sidecar | JARVIS sidecar | Fake benchmark first; real sidecar only after sanitizer |
| Avoid now | Shell | Hermes/JARVIS terminal paths | Disabled until AST allowlist/sandbox/approval |
| Avoid now | Desktop control | JARVIS desktop tools | Disabled until ScreenContextSanitizer and user approval |

## Promotion Criteria

`candidate -> lab fixture -> scanner -> fake benchmark -> Sentinel spec -> v0 implementation -> eval gate -> private staging`

## Kill Criteria

- Capability requires real credentials during development.
- Capability cannot produce a dry-run preview.
- Capability cannot be traced with input/output/action/evidence refs.
- Capability has no clear user value for GTM Operator or AgentOps Firewall.
- Capability pushes Sentinel toward generic desktop assistant before product pack quality is paid-ready.
