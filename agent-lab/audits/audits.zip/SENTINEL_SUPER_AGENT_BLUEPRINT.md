# Sentinel Super Agent Blueprint

Date: 2026-04-26
Status: G4 synthesis from source-only vendor forensics.

## Mission

Sentinel is not an OpenClaw, Hermes, OpenJarvis, or JARVIS integration. Sentinel is an original agent architecture that rewrites the useful mechanisms from first principles:

```text
see -> verify -> reason -> debate -> plan -> simulate -> approve -> execute -> trace -> learn
```

## Source Lessons

| Lesson | Vendor evidence | Sentinel design decision |
| --- | --- | --- |
| Runtime power needs a gate | JARVIS maps browser, desktop, terminal, and sidecar capabilities to authority/approval (`agent-lab/vendors/jarvis/source/src/authority/engine.ts:61-175`, `sidecar/handlers.go:15-67`). | Firewall is central, not optional. |
| Memory must not become policy | Hermes injects persistent memory into prompts (`agent-lab/vendors/hermes-agent/source/run_agent.py:1596-1704`); JARVIS labels user profile as untrusted (`agent-lab/vendors/jarvis/source/src/roles/prompt-builder.ts:149-157`). | Memory is contextual and typed; signed policy is separate. |
| Skills are supply chain | OpenJarvis imports skills from external sources and can import scripts (`agent-lab/vendors/openjarvis/source/src/openjarvis/cli/skill_cmd.py:162-245`; `skills/importer.py:128-135`). | Skills are scanned, quarantined, sandbox-tested, and approved before prompt index. |
| Cost is architecture | OpenJarvis routes by hardware/model tiers and reward weights (`agent-lab/vendors/openjarvis/source/src/openjarvis/core/config.py:209-300`, `:667-675`). | Every run has budget, route rationale, and hard cap. |
| Prompt context is attack surface | Hermes scans context files before prompt injection (`agent-lab/vendors/hermes-agent/source/agent/prompt_builder.py:32-75`). | Context compiler uses trust labels and injection scans. |

## Components

1. `SentinelPerception`
   - Inputs: idea, CueIdea report, uploaded evidence, safe web research output, user constraints.
   - Output: normalized, trust-labeled context.

2. `EvidenceLedger`
   - Stores CueIdea and research evidence as source-backed `EvidenceItem`.
   - Separates direct proof, adjacent proof, WTP, competitor gap, trend, pricing, and community signal.

3. `ResearchVerifier`
   - Enriches CueIdea evidence.
   - Flags evidence gaps instead of pretending certainty.

4. `DebateEngine`
   - Runs structured agents: SIGNAL, AXIOM, CIPHER, NOVA, FORGE, SKEPTIC/NEXUS.
   - Produces verdict and GTM decision with evidence refs.

5. `ActionPlanner`
   - Converts recommendations into proposed `AgentAction`.
   - No executor receives an unplanned action.

6. `Firewall`
   - Risk scorer, policy engine, dry-run, approval gate, and blocked-action ledger.
   - High/critical action cannot execute without explicit approval; some remain disabled.

7. `SafeExecutors`
   - v1: create folder, create markdown files, export JSON, prepare drafts, create watchlist.
   - No shell/email send/browser submit/desktop control in v1.

8. `TraceLedger`
   - Records import, evidence normalization, model route, prompt context, decision, action proposal, dry-run, approval, execution, output, feedback.

9. `LearningLayer`
   - Observes results and writes improvement proposals.
   - Never mutates production code, policies, skills, or prompts automatically.

## Hard Product Boundary

Allowed now:

- CueIdea evidence import.
- Research enrichment.
- GTM Pack generation.
- File generation under `data/generated_projects`.
- Draft-only outreach.
- Static vendor skill/runtime scans.
- Fake benchmarks.

Blocked now:

- real email send;
- real browser submit;
- shell execution;
- desktop automation;
- sidecar runtime;
- vendor bridge;
- unscanned skills;
- auto-code modification;
- payment/spend actions.

## North Star

Sentinel becomes the proof-backed operator layer that lets AI agents create business value while every risky action is scored, simulated, approved, and traced.
