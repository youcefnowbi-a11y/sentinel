# Sentinel Cost Router Spec

Date: 2026-04-26

## Source Lessons

- OpenJarvis maps hardware to inference engines and model tiers (`agent-lab/vendors/openjarvis/source/src/openjarvis/core/config.py:209-300`).
- OpenJarvis reward weights include accuracy, latency, cost, efficiency (`agent-lab/vendors/openjarvis/source/src/openjarvis/core/config.py:667-675`, `:726-760`).
- Hermes prompt caching policy shows provider behavior affects cost (`agent-lab/vendors/hermes-agent/source/run_agent.py:2638-2708`).

## Inputs

- run ID.
- user budget.
- run mode: quick, standard, deep.
- stage: import, extraction, research, debate, generation, firewall, eval.
- risk level.
- evidence density.
- expected token range.
- available local hardware.
- privacy constraints.
- model catalog with current pricing.

## Decision Formula Seed

```text
candidate_score =
  quality_weight(stage, risk) * quality_score
  + latency_weight(stage) * latency_score
  + cost_weight(budget) * cost_score
  + privacy_weight(data_sensitivity) * privacy_score
  + reliability_weight(stage) * reliability_score

hard reject if:
  estimated_cost > remaining_budget
  model lacks required tool/schema support
  privacy boundary violated
  stage requires high-confidence review and model is below threshold
```

## Outputs

```json
{
  "route_id": "route_...",
  "selected_provider": "...",
  "selected_model": "...",
  "fallback": "...",
  "estimated_input_tokens": 0,
  "estimated_output_tokens": 0,
  "estimated_cost_usd": 0.0,
  "remaining_budget_usd": 0.0,
  "reason": "...",
  "hard_cap_usd": 0.0
}
```

## Budget Rules

- Firewall/policy decisions get quality priority over cost.
- Draft copy generation gets cost priority.
- Deep research requires user-visible budget preview.
- Unknown pricing is treated as high uncertainty and capped.
- Every model call writes a cost trace.

## Required Evals

- Strong pack under budget.
- Deep mode asks for budget confirmation.
- Cache miss cannot exceed cap.
- Unknown provider pricing blocks deep run.
- Fallback route preserves trace continuity.
