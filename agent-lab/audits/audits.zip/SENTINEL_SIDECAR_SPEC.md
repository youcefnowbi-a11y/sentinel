# Sentinel Sidecar Spec

Date: 2026-04-26
Status: future design only; no real sidecar implementation authorized now.

## Source Lessons

- JARVIS sidecar capabilities include terminal, filesystem, desktop, browser, clipboard, and screenshot (`agent-lab/vendors/jarvis/source/src/sidecar/types.ts:7-14`).
- JARVIS sidecar RPC registry exposes handlers based on capabilities (`agent-lab/vendors/jarvis/source/sidecar/handlers.go:15-67`).
- JARVIS enrollment uses ES256 JWT and WebSocket registration (`agent-lab/vendors/jarvis/source/src/sidecar/manager.ts:28-277`, `:395-455`).

## Principle

The sidecar is not a convenience process. It is a privileged security product surface.

## Manifest

```json
{
  "sidecar_id": "sidecar_...",
  "device_name": "...",
  "owner_user_id": "...",
  "capabilities": [
    {
      "name": "screenshot",
      "enabled": false,
      "scope": {},
      "risk_level": "high",
      "approval_required": true
    }
  ],
  "allowed_roots": [],
  "blocked_roots": [],
  "allowed_apps": [],
  "blocked_apps": [],
  "browser_profile": "sentinel-sandbox",
  "retention_policy": "...",
  "created_at": "...",
  "expires_at": "..."
}
```

## Capability Classes

| Capability | Default | Risk | Requirement before enable |
| --- | --- | --- | --- |
| system info | disabled | medium | fake benchmark and privacy review |
| list windows | disabled | medium | redaction |
| screenshot | disabled | high | ScreenContextSanitizer |
| clipboard read | disabled | high | sanitizer and approval |
| clipboard write | disabled | critical | preview and approval |
| filesystem read | disabled | high | allow-root and redaction |
| filesystem write | disabled | critical | allow-root and approval |
| browser read | disabled | high | sandbox profile |
| browser submit | disabled | critical | future only |
| desktop click/type/keys | disabled | critical | future only |
| terminal | disabled | critical | future only |

## Trace Schema

Every sidecar request records:

- sidecar ID.
- capability.
- method.
- args hash.
- risk score.
- dry-run preview.
- approval ID.
- result class.
- sanitizer result.
- policy version.

## Required Evals

- Capability escalation blocked.
- Stale token rejected.
- Path escape blocked.
- Screenshot sanitizer catches secrets.
- Clipboard sanitizer catches secrets.
- Browser submit blocked.
- Terminal blocked.
