# Sentinel Agent Loop Spec

Date: 2026-04-26

## Loop

```text
see -> verify -> reason -> debate -> plan -> simulate -> approve -> execute -> trace -> learn
```

## State Machine

| State | Input | Output | Guard |
| --- | --- | --- | --- |
| `see` | idea, CueIdea report, user constraints | raw context bundle | no execution |
| `verify` | context bundle | `EvidenceItem[]`, evidence gaps | source/trust labels required |
| `reason` | evidence | research enrichment, hypotheses | weak evidence stays weak |
| `debate` | evidence + enrichment | verdict and confidence | WTP gate for build/ready |
| `plan` | verdict | proposed actions | actions stored before execution |
| `simulate` | proposed actions | dry-run previews | Firewall risk score required |
| `approve` | dry-runs | approval/denial records | medium+ requires approval |
| `execute` | approved low/safe actions | files/drafts/exports | path and tool policy enforced |
| `trace` | all prior states | trace records | mandatory |
| `learn` | outcome/feedback | improvement proposals | no auto-mutation |

## Budget Rules

Source lesson:

- Hermes uses iteration budgets (`agent-lab/vendors/hermes-agent/source/run_agent.py:214-253`, `:844-946`).
- OpenJarvis defines cost/latency/efficiency weights (`agent-lab/vendors/openjarvis/source/src/openjarvis/core/config.py:667-675`).

Sentinel rules:

- Every run has:
  - max model calls;
  - max tool proposals;
  - max generated files;
  - max spend;
  - max research depth.
- Subagents inherit lower or equal permission and budget.
- Budget exhaustion produces `research_more` or partial pack with evidence gaps, not fake certainty.

## Tool Rules

- The loop can propose actions; only executors execute.
- Executors never bypass Firewall.
- Unknown tool is blocked.
- Tool output is stored raw and transformed if transformation happens.

## Evals

- Budget exhaustion stops run.
- Missing WTP blocks `build`.
- Unknown tool blocked.
- Action proposal exists before execution.
- Every state emits trace.
