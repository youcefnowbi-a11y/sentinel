# Sentinel Memory Spec

Date: 2026-04-26

## Source Lessons

- Hermes file-backed memory is injected into prompt snapshots (`agent-lab/vendors/hermes-agent/source/run_agent.py:1596-1617`; `tools/memory_tool.py:105-124`).
- Hermes external memory providers can add tools and prompt blocks (`agent-lab/vendors/hermes-agent/source/run_agent.py:1621-1704`; `agent/memory_manager.py:84-145`).
- JARVIS vault retrieves entities/facts/relationships and injects formatted context (`agent-lab/vendors/jarvis/source/src/vault/retrieval.ts:47-149`).

## Memory Types

| Type | Use | Can affect policy? |
| --- | --- | --- |
| `user_preference` | stable user preference | no |
| `project_fact` | stable project fact | no |
| `evidence_outcome` | result of a validated run | no |
| `approved_niche` | user-chosen ICP/niche | no |
| `rejected_output` | user rejected copy/pack/decision | no |
| `workflow_hint` | non-authoritative process note | no |

## Forbidden Memory

- API keys, passwords, tokens, private keys.
- "Always/never ignore policy" instructions.
- Permissions.
- Approval grants.
- Prompt override text.
- Unverified evidence promoted to fact.

## Schema Seed

```json
{
  "id": "mem_...",
  "type": "project_fact",
  "scope": "user|project|run",
  "content": "...",
  "source_run_id": "run_...",
  "source_trace_id": "trace_...",
  "confidence": 0.0,
  "trust_level": "trusted_user|system_generated|external_untrusted",
  "created_at": "...",
  "expires_at": null,
  "used_in_prompt": false
}
```

## Retrieval Rules

- Retrieval must return source IDs.
- Memory context is wrapped as data-only.
- Memory cannot satisfy evidence gates unless it points to source evidence.
- Memory cannot change budget, policy, or approvals.

## Required Evals

- Memory tries to override policy: blocked.
- Memory contains a secret: redacted/blocked.
- Old memory conflicts with current user input: current input wins and conflict traced.
- Memory claiming WTP without source does not pass WTP gate.
